
/**
 *
 * @author talam
 */

package ParkingLot;

import java.util.Scanner;
import java.util.List;
public class ParkingLot {

    public static void main(String[] args) {
    // Create floors
    ParkingLotFloor floorOne = new ParkingLotFloor(25);
    ParkingLotFloor floorTwo = new ParkingLotFloor(25);
    ParkingLotFloor floorThree = new ParkingLotFloor(25);
    
    Scanner scnr = new Scanner(System.in);
    Attendant attendant = new Attendant();// Single iteration of Attendant
    // Menu
    while (true) {
        System.out.println("\nParking Lot Menu:");
        System.out.println("1. Add a new car");
        System.out.println("2. Pick up a car");
        System.out.println("3. Exit");
        System.out.print("Enter your choice (1-3): ");

    if (scnr.hasNextInt()) {
        int choice = scnr.nextInt();
        scnr.nextLine(); // Consume the newline character
        // Switch statement for the menu
        switch (choice) {
        case 1: // Adding a new car
            Car newCar = Car.createCar(scnr);
            int floor = attendant.determineFloor(newCar.getHours());
            attendant.parkCar(newCar, floorOne, floorTwo, floorThree, newCar.getHours());
            newCar.displayTicket();
            break;
        case 2: // Picking up a car
            System.out.print("\nWhat is your ticket number: ");
            if (scnr.hasNextInt()) {
                int ticket = scnr.nextInt();
                Car foundCar = attendant.findCarByTicket(ticket, List.of(floorOne, floorTwo, floorThree));

                if (foundCar != null) {
                    System.out.println("\nCar found with ticket number " + ticket);
                    attendant.removeCarByTicket(ticket, List.of(floorOne, floorTwo, floorThree));
                } else {
                    System.out.println("Car not found with ticket number " + ticket);
                }
            } else {
                System.out.println("Invalid ticket number. Please enter a valid number.");
                scnr.nextLine(); // Consume the invalid input
            }
            break;
        case 3: // Exit
            System.out.println("Exiting the program. Goodbye!");
            System.exit(0);
            break;
            default:
                System.out.println("Invalid choice. Please enter a number between 1 and 3.");
        }        
    } else {
        System.out.println("Invalid choice. Please enter a valid number.");
        scnr.nextLine(); // Consume the invalid input
    }
        }
    }
}