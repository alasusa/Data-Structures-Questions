package ParkingLot;
import java.util.List;

public class Attendant {
    
    int level = 0;

    //Determines what floor to park on based of expected hours
    public int determineFloor(double expectedHours) {
        if (expectedHours <= 3) {
            level = 1;
        } else if (expectedHours <= 6) {
            level = 2;
        } else if (expectedHours <= 12) {
            level = 3;
        } else {
            level = 0; // Unknown floor
        }
        return level;
    }

    //Placing the car on the proper floor
    public void parkCar(Car car, ParkingLotFloor floorOne, ParkingLotFloor floorTwo, ParkingLotFloor floorThree, double expectedHours) {
        int floor = determineFloor(expectedHours);

        if (floor >= 1 && floor <= 3) {
            car.setParkingInfo(floor, 0);  // Set the correct floor value
            switch (floor) {
                case 1 -> floorOne.parkCar(car);
                case 2 -> floorTwo.parkCar(car);
                case 3 -> floorThree.parkCar(car);
            }           
        } else {
            System.out.println("Invalid car information or expected hours.");
        }
    }
    // This is the removing car method it uses the findCarByTicket method
    public void removeCarByTicket(int ticket, List<ParkingLotFloor> floors) {

        for (ParkingLotFloor floor : floors) {
            Car foundCar = floor.findCarByTicket(ticket);
            if (foundCar != null) {
                floor.removeCar(foundCar);
                System.out.println("Car with the ticket number " + ticket + 
                        "\nsuccessfully removed from " + foundCar.getFloor() + 
                        ":"+foundCar.getSpot()+".");
                return; // Exit the method if the car is found and removed
            }
        }
        // If the loop completes, the car with the specified ticket was not found
        System.out.println("Car with the ticket " + ticket + " not found.");
    }
    // How the car is found based off the ticket number
    public Car findCarByTicket(int ticket, List<ParkingLotFloor> floors) {
        for (ParkingLotFloor floor : floors) {
            Car foundCar = floor.findCarByTicket(ticket);
            if (foundCar != null) {
                return foundCar;
            }
        }
        return null;  // Car not found
    }
}

